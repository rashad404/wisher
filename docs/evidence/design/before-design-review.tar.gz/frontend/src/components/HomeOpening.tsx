'use client';

import {useState} from 'react';
import Link from 'next/link';
import {useRouter} from 'next/navigation';
import HomeSections from './HomeSections';
import s from './HomeOpening.module.css';

export function Icon({name}:{name:string}) {
 const paths:Record<string,string>={menu:'M4 7h16M4 12h16M4 17h16',close:'m6 6 12 12M18 6 6 18',arrow:'M4 12h16m-6-6 6 6-6 6',gift:'M3 8h18v4H3zM5 12v9h14v-9M12 8v13M12 8H8a3 3 0 1 1 3-3l1 3Zm0 0h4a3 3 0 1 0-3-3l-1 3Z',home:'m3 10 9-7 9 7M5 9v12h14V9M9 21v-8h6v8',heart:'M20 5a5 5 0 0 0-8 1 5 5 0 0 0-8-1c-5 5 8 15 8 15S25 10 20 5Z',user:'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8M4 21v-2a7 7 0 0 1 7-5h2a7 7 0 0 1 7 5v2',calendar:'M4 5h16v16H4zM8 2v6M16 2v6M4 11h16',business:'M4 7h16v14H4zM9 7V3h6v4M4 12h16M10 12v3h4v-3'};
 return <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name]}/></svg>;
}
export function Brand(){return <Link href="/" className={s.brand} aria-label="Wisher ana səhifə"><img src="/logo.svg" width="36" height="36" alt=""/>wisher<span>.az</span></Link>}
export default function HomeOpening(){
 const router=useRouter();const [recipient,setRecipient]=useState(0);
 const people=['Dostuma','Ailəmə','Əməkdaşıma'];
 const examples=[['Ad günü','Onun zövqünə uyğun bir hədiyyə.'],['Özəl bir gün','Sevdiklərinizə kiçik bir sürpriz.'],['Təşəkkür','Əməyinə dəyər verən bir hədiyyə.']];
 function show(section:string){router.push(section==='gifts'?'/gifts':section==='greetings'?'/wishes':'/companies')}
 return <>
  <main className={s.main}><section className={s.opening} aria-labelledby="opening-title"><div className={s.copy}><div className={s.eyebrow}><span/>Hədiyyə də, xoş söz də.</div><h1 id="opening-title">Sevindirəcək<br/>bir <em>hədiyyə.</em><br/>Sizə aid sözlər.</h1><p>Yaxınlarınız üçün hədiyyə seçin, ürəyinizdən keçənləri təbrikə çevirin. Özəl günlər diqqətdən kənarda qalmasın.</p><div className={s.actions}><button className={s.primary} onClick={()=>show('gifts')}>Hədiyyə tap<Icon name="arrow"/></button><button className={s.secondary} onClick={()=>show('greetings')}>Təbrik hazırla<Icon name="heart"/></button></div><div className={s.storeNote}><Icon name="gift"/><span>Hədiyyəni seçin, mağazanın saytından alın.</span></div></div>
  <div className={s.stage}><div className={s.stageTop}><span>Kimə hədiyyə axtarırsınız?</span><span className={s.example}>Nümunə</span></div><div className={s.recipients} aria-label="Hədiyyə alacağınız şəxs">{people.map((person,i)=><button key={person} aria-pressed={recipient===i} onClick={()=>setRecipient(i)}>{person}</button>)}</div><div className={s.scene}><span className={s.sparkOne} aria-hidden="true">+</span><span className={s.sparkTwo} aria-hidden="true">+</span><div className={s.occasion}><Icon name="calendar"/><span>{examples[recipient][0]}</span></div><div className={s.note}><span>Sizin sözlərinizlə</span><Icon name="heart"/><strong>Yaxşı ki,<br/>varsan!</strong><span>wisher.az</span></div><div className={s.gift} aria-hidden="true"><div className={s.bow}><i/><i/></div><div className={s.lid}/><div className={s.box}/><div className={s.ribbon}/><span className={s.tag}>sənin üçün</span></div></div><div className={s.stageBottom} aria-live="polite"><div><span>Kiçik bir diqqət</span><h2>{examples[recipient][1]}</h2></div><button aria-label="Hədiyyə seçimi haqqında" onClick={()=>show('gifts')}><Icon name="arrow"/></button></div></div>
  </section><div className={s.companyLine}><span><Icon name="business"/>Komandanızı da sevindirin.</span><button onClick={()=>show('companies')}>Şirkətlər üçün Wisher<Icon name="arrow"/></button></div></main>
  <HomeSections/>
 </>;
}
